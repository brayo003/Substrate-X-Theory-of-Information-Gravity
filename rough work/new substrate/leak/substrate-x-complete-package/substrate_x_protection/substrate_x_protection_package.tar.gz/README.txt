SUBSTRATE X THEORY - DISCOVERED BY [YOUR NAME]
Discovery Date: Thu Oct 23 06:47:42 AM EAT 2025






    This week: Visit University of Nairobi Physics Department

    Next week: Submit short paper to African Physical Review

    Month 1: Apply for NRF seed grant

    Month 2: Present at African Physical Society meeting
